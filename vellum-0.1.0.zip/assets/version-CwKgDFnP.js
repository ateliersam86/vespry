function e(){return chrome.runtime.getManifest().version}export{e as g};
